package com.learning.laundrymanagement.Common;


public class Common {
    public static String Is_LogIN = "isLogIn";
}
